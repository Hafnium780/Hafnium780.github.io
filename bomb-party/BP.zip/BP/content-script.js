var turn = document.getElementsByClassName("selfTurn")[0];
var syl = document.getElementsByClassName("syllable")[0];
var entry = document.querySelector(".selfTurn form input");
var form = document.querySelector(".selfTurn form");

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "enable") {
    enabled = msg.enabled;
    if (enabled) {
      run();
    } else {
      end();
    }
  } else if (msg.type === "lessnesses") {
    lessnesses = msg.enabled;
  } else if (msg.type === "type") {
    typing = msg.enabled;
  } else if (msg.type === "length") {
    length = msg.length;
  }
});

let enabled, lessnesses, typing, length;
chrome.storage.local.get(["enable"]).then((v) => {
  enabled = v.enable;
  if (enabled) setTimeout(run, 1000);
});
chrome.storage.local
  .get(["lessnesses"])
  .then((v) => (lessnesses = v.lessnesses));
chrome.storage.local.get(["type"]).then((v) => (typing = v.type));
chrome.storage.local.get(["length"]).then((v) => (length = v.length));

let toType = "";

let used, words;
let usedLetters = Array(24).fill(false);

fetch(chrome.runtime.getURL("dict.txt"))
  .then((response) => response.text())
  .then((data) => {
    words = data.split(/\r?\n/);
    words.pop();
    used = Array(words.length).fill(false);
  });

let interval = undefined;
let pause = 0;

function run() {
  if (interval !== undefined) clearInterval(interval);
  interval = setInterval(() => {
    if (pause > 0) {
      pause--;
      return;
    }
    if (turn.innerText == "" && (toType == "" || !typing)) {
      let maxScore = 0;
      let maxStr = "";
      let maxi = 0;
      let maxScore1 = 0;
      let maxStr1 = "";
      let maxi1 = 0;
      let sub = syl.innerText;
      for (let i = 0; i < words.length; i++) {
        if (!used[i] && words[i].includes(sub)) {
          let score = evalStr(words[i]);
          if (words[i].length <= length) {
            if (
              score > maxScore ||
              (score == maxScore && words[i].length > words[maxi].length)
            ) {
              maxScore = score;
              maxi = i;
              maxStr = words[i];
            }
          }
          if (
            score > maxScore1 ||
            (score == maxScore1 && words[i].length > words[maxi1].length)
          ) {
            maxScore1 = score;
            maxi1 = i;
            maxStr1 = words[i];
          }
        }
      }
      if (maxStr == "") {
        maxStr = maxStr1;
        maxi = maxi1;
      }
      used[maxi] = true;
      for (let i = 0; i < maxStr.length; i++) {
        let index = ind(maxStr[i]);
        if (index != -1) usedLetters[index] = true;
      }
      let done = true;
      for (let i = 0; i < usedLetters.length; i++) {
        done = done && usedLetters[i];
      }
      if (done) usedLetters.fill(false);
      if (typing) {
        toType = maxStr;
        setTimeout(type, 200);
      } else {
        entry.value = maxStr;
        form.dispatchEvent(new Event("submit"));
      }
    }
  }, 500);

  function evalStr(s) {
    let score = 0;
    if (lessnesses && s.substring(s.length - 10, 10) == "LESSNESSES")
      score = 10000;
    for (let i = 0; i < s.length; i++) {
      let index = ind(s[i]);
      if (index != -1 && !usedLetters[index]) score++;
    }
    return score;
  }

  function ind(c) {
    let d = c.charCodeAt(0) - "A".charCodeAt(0);
    if (d >= 23) {
      if (d == 24) return 23;
      return -1;
    }
    return d;
  }
}

function type() {
  entry.value += toType[0];
  toType = toType.substring(1, toType.length);
  entry.dispatchEvent(new Event("input"));

  if (toType != "") {
    setTimeout(type, Math.floor(Math.random() * 100));
  } else {
    form.dispatchEvent(new Event("submit"));
    pause = 2;
  }
}

function end() {
  if (interval !== undefined) clearInterval(interval);
  interval = undefined;
}
