let enable = document.getElementsByClassName("enable")[0];
let lessnesses = document.getElementsByClassName("lessnesses")[0];
let type = document.getElementsByClassName("type")[0];
let length = document.getElementById("length");

chrome.storage.local.get(["enable"]).then((v) => (enable.checked = v.enable));
chrome.storage.local
  .get(["lessnesses"])
  .then((v) => (lessnesses.checked = v.lessnesses));
chrome.storage.local.get(["type"]).then((v) => (type.checked = v.type));
chrome.storage.local.get(["length"]).then((v) => {
  if (v.length === undefined) length.value = "25";
  else length.value = v.length;
});

enable.addEventListener("change", (event) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "enable",
      enabled: event.target.checked,
    });
  });
  chrome.storage.local.set({ enable: event.target.checked });
});

lessnesses.addEventListener("change", (event) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "lessnesses",
      enabled: event.target.checked,
    });
  });
  chrome.storage.local.set({ lessnesses: event.target.checked });
});

type.addEventListener("change", (event) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "type",
      enabled: event.target.checked,
    });
  });
  chrome.storage.local.set({ type: event.target.checked });
});

length.addEventListener("change", (event) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "length",
      length: event.target.value,
    });
  });
  chrome.storage.local.set({ length: event.target.value });
});
